# jQuery-File-Upload.MVC5
Simple implementation of Blueimp jQuery File Upload Plugin with MVC5


1. How to run a project in my visual studio?

WINDONWS + R > cmd > mkdir demo > cd demo git clone https://github.com/TheKalin/jQuery-File-Upload.MVC5.git

Go to visual studio File > Open > Project/Solution > Point to /jQuery-File-Upload.MVC5.sln

Build > Build Solution Run project 

Explore!